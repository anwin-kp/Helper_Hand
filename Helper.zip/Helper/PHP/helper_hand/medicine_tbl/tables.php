<?php
$table="medicine";
$target_path = "uploads/";
$title="Medicine Details";
?>