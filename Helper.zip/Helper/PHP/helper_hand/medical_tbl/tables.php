<?php
$table="medical_reg";
$target_path = "uploads/";
$title="Medical Details";
?>