
<?php
 error_reporting(0);
include('header.php');

       include("connection.php");

?>
<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action="" method="POST" enctype="multipart/form-data"><br>
     <label>Amount:</label><input type="text" name="amount" value='<?php echo $_REQUEST['amt']?>' class='form-control'><br>
   
   <center>  <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>

<?php
if(isset($_POST['submit']))
       {
		   mysqli_query($con,"UPDATE cart SET status='PAYED' where status='ORDERED' and user_id='$_REQUEST[uid]'");
		   
		   echo" SUCCESS FULLY BOOKED";
	   }

?>