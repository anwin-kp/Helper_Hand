<?php
include("header.php");
//include("connection.php");

?>
 <h4>History</h4>
    
    <table class="table table-striped" >
                        
                           
                              <?php
                                $con = mysqli_connect("localhost","root","","helper");  //connection query
                            
                                $sel="select * from  cart WHERE user_id='$_REQUEST[uid]'"; 
                                    
                                $res=mysqli_query($con,$sel);
                                while($row=mysqli_fetch_array($res))
                                {
									
									$sel2="select * from  medicine WHERE id='$row[item_id]'"; 
                                    
                                $res2=mysqli_query($con,$sel2);
                                $row2=mysqli_fetch_array($res2);
                            ?>
                          <div class='well'>
						 BillNo: #<?php echo $row['bill_no']; ?>
						  Item :<?php echo $row2['name']; ?>
						  Qty :<?php echo $row['quantity']; ?>
						    Price :<?php echo $row['price']; ?>
							  Status :<?php echo $row['status']; ?>
						  </div>
                            <?php
                                }
                            
                            ?>  
                                
                            
                        </table>
