<?php
include("header.php");
//include("connection.php");

?>
 <h4>Doners</h4>
    
    <table class="table table-striped" >
                        
                           
                              <?php
                                $con = mysqli_connect("localhost","root","","helper");  //connection query
                            
                                $sel="select * from  donor"; 
                                    
                                $res=mysqli_query($con,$sel);
                                while($row=mysqli_fetch_array($res))
                                {
                            ?>
                          <div class='well'>
            <label>  Full Name :</label><?php echo $row['full_name']; ?><br>
              <label> Address :</label><?php echo $row['address']; ?><br>
             <label>  Pincode :</label><?php echo $row['pincode']; ?><br>
              <label>  Phone no :</label><?php echo $row['phoneno']; ?><br>
               <label>  Blood Group :</label><?php echo $row['blood_group']; ?><br><br>
              
              </div>
                            <?php
                                }
                            
                            ?>  
                                
                            
                        </table>
