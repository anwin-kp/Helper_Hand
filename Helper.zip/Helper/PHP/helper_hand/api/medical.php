<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
     <label>store_name:</label><input type="text"name="store_name" class='form-control'><br>
     <label>email:</label><input type="text"name="email"class='form-control'><br>
     <label>password:</label><input type="text" name="password"class='form-control'><br>
	 <label>contact_number:</label><input type="text" name="contact_number"class='form-control'><br>
     
	 
   <center>  <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>
     <?php
     error_reporting(0);
       include("connection.php");
       if(isset($_POST['submit']))
       {

        $store_name=$_POST['store_name'];
        $email=$_POST['email'];
        $password=$_POST['password'];
        $contact_number=$_POST['contact_number'];
        $symptom=$_POST['symptom'];
        $stock=$_POST['stock'];

        $ins="INSERT INTO medical_reg(store_name,email,password,contact_number,symptom,stock)VALUES('$store_name','$email','$password','$contact_number')";
          $res= mysqli_query($con,$ins);
          if(res)
          {
echo "<script>
alert('inserted');

</script>";

          }

        }
     ?>


 </div>
  </body>
  </html>