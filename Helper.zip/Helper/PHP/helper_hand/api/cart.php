<?php
$id=$_REQUEST['uid'];
include("header.php");
?>
<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
 
 <h3>CART</h3>
    <?php
	$tot=0;
	$t=0;
	include("connection.php");
	
	if(isset($_REQUEST['delid']))
	{
		mysqli_query($con,"DELETE  FROM cart where id='$_REQUEST[delid]'");
		
	}
	$result = mysqli_query($con,"SELECT * FROM cart where user_id='$id' and status='cart' ");
	

		while($row = mysqli_fetch_array($result))
		{
			$t=$row['quantity']*$row['price'];
			
			$tot=$tot+$t;
			 $ins2="SELECT * FROM medicine WHERE id='$row[item_id]'";
			 $res2= mysqli_query($con,$ins2);
			 $row2=mysqli_fetch_array($res2);
			
			echo"<div class='well'><h1>$row2[name]</h1><br>
			<p>Qty : $row[quantity]Nos <br>
			Rate : $t Rs
			</p>
			<a href='?delid=$row[id]&uid=$id' class='btn btn-danger'>Del</a>
			</div>
			
			";
		}
	
	if($tot!=0)
	{
	echo "
	
	
	<h3> TOTAL :$tot RS</h3>";
	echo"
	<a href='confirm.php?amt=$tot&uid=$id' class='btn btn-danger'>Take away</a>
	<a href='confirm1.php?amt=$tot&uid=$id' class='btn btn-primary'>Delivey Boy</a>
	
	
	";
	}
	else
	{
		echo"<h2>NO DATA</h2>";
	}
	
	?>
	
	
	


 </div>
  </body>
  </html>