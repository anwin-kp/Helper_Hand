<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
     <label>FULL NAME:</label><input type="text"name="full_name" class='form-control'><br>
     <label>ADDRESS:</label><input type="text" name="address"class='form-control'><br>
     <label>PIN CODE:</label><input type="text"name="pincode"class='form-control'><br>
     <label>PHONE NUMBER:</label><input type="text" name="phoneno"class='form-control'><br>
    <label>BLOOD GROUP:</label><input type="text" name="blood_group"class='form-control'><br>

   <center>  <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>
     <?php
     error_reporting(0);
       include("connection.php");
       if(isset($_POST['submit']))
       {

        $full_name=$_POST['full_name'];
        $address=$_POST['address'];
        $pincode=$_POST['pincode'];
        $phoneno=$_POST['phoneno'];
        $blood_group=$_POST['blood_group'];
          $ins="INSERT INTO donor(full_name,address,pincode,phoneno,blood_group) VALUES('$full_name','$address','$pincode','$phoneno','$blood_group')";
          $res= mysqli_query($con,$ins);
          if(res)
          {
echo "<script>
alert('inserted');

</script>";

          }

        }
     ?>


 </div>
  </body>
  </html>