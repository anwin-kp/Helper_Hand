
<?php
 error_reporting(0);
include('header.php');

       include("connection.php");
?>
<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action="" method="POST" enctype="multipart/form-data"><br>
     <label>Amount:</label><input type="text" name="amount" value='<?php echo $_REQUEST['amt']?>' class='form-control'><br>
    <label>Prescription:</label><input type="file" name="uploadedfile"  class='form-control'><br>
     <label>Status:</label><input type="text" name="status"value='TAKEAWAY' readonly class='form-control'><br>
	  <label>Address:</label><input type="text" name="address" class='form-control'><br>
   <center>  <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>

<?php

if(isset($_POST['submit']))
       {
$target_path = "../prescription/uploads/";

$target_path = $target_path . basename( $_FILES['uploadedfile']['name']); 

    if(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
        echo "The file ".  basename( $_FILES['uploadedfile']['name']). 
        " has been uploaded";
    } else{
        echo "There was an error uploading the file, please try again!";
    }

$sql = "INSERT INTO prescription(user,amount,prescription,status,address) VALUES ('$_REQUEST[uid]','$_POST[amount]','$target_path','$_POST[status]','$_POST[address]')";
// echo $sql;

if(mysqli_query($con,$sql))
{
	$iid=mysqli_insert_id($con);
	
	mysqli_query($con,"UPDATE cart SET status='ORDERED',delivery_status='$_POST[status]',bill_no='$iid' where status='cart' and user_id='$_REQUEST[uid]' ");
	header("location:pay.php?id=$iid&amt=$_POST[amount]&uid=$_REQUEST[uid]");
}

else{
	echo "failed";
}

}

?>