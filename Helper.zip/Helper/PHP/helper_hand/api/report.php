<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
 <body>	 
 	<div class="container mt-3">
 	<form action=""method="POST"enctype="multipart/form-data">
 		 <label>USER_ID:</label><input type="text"name="userid"class='form-control'><br>
 		 <label>Vehicle_no:</label><input type="text"name="vehicle_no"class='form-control'><br> 
 		 <label>Image:</label><input type="file"name="f1"><br><br>
 		 <label>Description:</label><input type="textarea" rows="15" cols="20" name="description"class='form-control'><br>
 		 <center><input type="submit"name="submit"style="width:150px;background:darkblue;color: white;height:40px;"></center>
  </form>
     <?php
       include("connection.php");
       if(isset($_POST['submit']))
       {

        $userid=$_POST['userid'];
        $vehicleno=$_POST['vehicle_no'];
        $description=$_POST['description'];
         

         $img=$_FILES['f1']['name'];


        if($_FILES['f1']['name']){

          move_uploaded_file($_FILES['f1']['tmp_name'],"uploads/".$_FILES['f1']['name']);
         

        }
        $ins="INSERT INTO accident_tbl(user_id,vehicle_no,description,image) VALUES('$userid','$vehicleno','$description','$img')";
        // echo $ins;
        mysqli_query($con,$ins);

       }

     ?>


 </div>
  </body>
  </html>