<?php
include("header.php");
//include("connection.php");

?>
 <h4>Profile</h4>
    
    <table class="table table-striped" >
                        
                           
                              <?php
                                $con = mysqli_connect("localhost","root","","helper");  //connection query
                            
                                $sel="select * from  user_tbl where id='$id'"; 
                                    
                                $res=mysqli_query($con,$sel);
                                while($row=mysqli_fetch_array($res))
                                {


                            ?>
                            <tr>
                            <th>NAME</th><td><?php echo $row['name']?></td>
                            </tr>
                            <tr>
                            <th>ADDRESS</th>    <td><?php echo $row['address']?></td>
                            </tr>
                            <tr>
                            <th>Email</th><td> <?php echo $row['email']?></td>
                            </tr>
                            <tr>
                            <th>PHONE NO</th>    <td><?php echo $row['phone']?></td>
                            </tr>
                            <tr>
                            <th>USER NAME</th>    <td><?php echo $row['username']?></td>
                            </tr>
                            <tr>
                            <th>BLOOD GROUP</th>    <td><?php echo $row['blood_group']?></td>
                            </tr>
                        
                            <?php
                                }
                            
                            ?>  
                                
                            
                        </table>
