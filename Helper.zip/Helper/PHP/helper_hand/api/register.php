<?php

$con = mysqli_connect("localhost","root","","helper");

//$user_id =$_POST['userid'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$bloodgroup = $_POST['bloodgroup'];
$username = $_POST['username'];
$password = $_POST['password'];

$sql = "INSERT INTO user_tbl(name,email,phone,address,blood_group,username,password) VALUES ('$name','$email','$phone','$address','$bloodgroup','$username','$password')";
// echo $sql;

if(mysqli_query($con,$sql))
{
	echo "success";
}
else{
	echo "failed";
}

?>