<?php
$id=$_REQUEST['uid'];
include("header.php");
?>
<html>
<head>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
 <body>  
  <div class="container col-sm-12">
  <form action=""method="POST"><br>
     <label>Name:</label><input type="text" name="name" placeholder='Search Medicine' class='form-control'><br>
     
   <center> 
   <input type="submit"name="submit" class='btn btn-danger'><center>
  </form>
     <?php
    # error_reporting(0);
       include("connection.php");
	   
	   if(isset($_POST['ccc']))
	   {
		   $date=date('Y-m-d');
		   $query7="INSERT INTO cart(item_id,store,quantity,price,order_date,user_id,status) VALUES ('$_POST[mid]','$_POST[sid]','$_POST[sqty]','$_POST[price]','$date','$id','cart')";
		   
		   
		   //echo $query7;
 mysqli_query($con,$query7);
 

 mysqli_query($con,"UPDATE medicine SET quantity=quantity-$_POST[sqty] WHERE id='$_POST[mid]'");
 
	   }
	   
	   
	   
	   
	   
       if(isset($_POST['submit']))
       {
		   $ins="SELECT * FROM medicine WHERE name LIKE '%$_POST[name]%' and stock='Available'";
	   }
	   else
	   {
		     $ins="SELECT * FROM medicine WHERE stock='Available' ";
	   }
        
		$res= mysqli_query($con,$ins);
		
		while($row=mysqli_fetch_array($res))
		{
		
			echo"<div class='well'>
			
			<h3>$row[name]</h3><br>
			<b>QTY : </b>$row[quantity]<br>
			<b>Rate : </b>$row[price] Rs<br>
			
			<p>
			
			<form method='post' action=''>
			<input type='hidden' name='mid' value='$row[id]' />
			<input type='hidden' name='sid' value='$row[store]' />
			<input type='hidden' name='price' value='$row[price]' />
			<br><br>
			Qty: <input type='number' name='sqty' max='$row[quantity]' required /> <br><br>
			
			<input type='submit' class='btn btn-success' name='ccc'  value='Add to Cart' ></p>
			</form>
			</div>
			
			";
			
			
		}
         
      echo"<center><a href='cart.php?uid=$id'>VIEW CART</a></center>";
     ?>


 </div>
  </body>
  </html>