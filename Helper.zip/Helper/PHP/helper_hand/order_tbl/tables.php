<?php
$table="cart";
$target_path = "uploads/";
$title="Order details";
?>