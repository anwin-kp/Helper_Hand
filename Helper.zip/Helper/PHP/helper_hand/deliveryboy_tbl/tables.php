<?php
$table="deliveryboy";
$target_path = "uploads/";
$title="Delivery Boy Details";
?>