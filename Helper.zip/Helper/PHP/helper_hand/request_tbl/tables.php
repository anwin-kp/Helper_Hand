<?php
$table="request";
$target_path = "uploads/";
$title="Request details";
?>