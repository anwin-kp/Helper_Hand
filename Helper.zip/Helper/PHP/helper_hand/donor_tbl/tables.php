<?php
$table="donor";
$target_path = "uploads/";
$title="Donor details";
?>