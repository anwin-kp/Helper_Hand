<?php
ob_start();
session_start();
include('../db/connectionI.php');
//$db_name="music"; // Database name 
$tbl_name="employee"; // Table name 

// Connect to server and select databse.


// username and password sent from form 
$myusername=$_POST['UserName']; 
$mypassword=$_POST['Password']; 


if(isset($_POST['login']))
{
//

if($myusername=="admin" and $mypassword="admin")
{
		$_SESSION['type']="admin";
header("location:../dashboard/dashboard.php");
}
else
{
	$tbl_name="medical_reg"; // Table name 


$sql="SELECT * FROM $tbl_name WHERE email='$myusername' and password='$mypassword'";
$result=mysqli_query($con,$sql);


 $result = mysqli_query($con,"SELECT * FROM $tbl_name WHERE email='$myusername' and password='$mypassword'") or die('Could not connect: ' . mysqli_error($con));
$f=0;
while($row = mysqli_fetch_array($result))
  {
	  
	  

	$_SESSION['type'] ="store";
	$_SESSION['userid'] =$row['id'];
	header("location:../dashboard/dashboard.php");
	$f=1;
	  
  }
	
	
 if($f==0)
header("location:login.php");

}




}
else{
	 if($f==0)
header("location:login.php");

}

?>
 
 



