<?php
$table="prescription";
$target_path = "uploads/";
$title="Prescription details";
?>