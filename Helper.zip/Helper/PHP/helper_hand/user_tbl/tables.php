<?php
$table="user_tbl";
$target_path = "uploads/";
$title=" User details";
?>