-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2022 at 04:50 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `helper`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `item_id` varchar(50) NOT NULL,
  `store` varchar(100) NOT NULL,
  `quantity` varchar(500) NOT NULL,
  `price` varchar(1000) NOT NULL,
  `order_date` date NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `delivery_status` varchar(100) NOT NULL,
  `bill_no` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `item_id`, `store`, `quantity`, `price`, `order_date`, `user_id`, `status`, `delivery_status`, `bill_no`) VALUES
(5, '1', '1', '2', '3', '2022-05-25', '1', 'cart', 'DELIVERD', 0),
(6, '1', '1', '3', '3', '2022-05-25', '1', 'cart', 'DELIVERD', 0),
(7, '1', '1', '2', '3', '2022-05-25', '3', 'PAYED', 'TAKEAWAY', 1),
(9, '1', '1', '2', '3', '2022-05-25', '3', 'PAYED', 'TAKEAWAY', 2),
(10, '1', '1', '2', '3', '2022-05-25', '3', 'PAYED', 'TAKEAWAY', 3),
(11, '1', '1', '2', '3', '2022-05-26', '3', 'PAYED', 'TAKEAWAY', 4),
(12, '1', '1', '3', '3', '2022-05-26', '3', 'PAYED', 'TAKEAWAY', 4),
(13, '1', '1', '2', '3', '2022-05-26', '3', 'PAYED', 'TAKEAWAY', 5),
(14, '1', '1', '3', '3', '2022-05-26', '3', 'PAYED', 'TAKEAWAY', 5),
(15, '1', '1', '2', '3', '2022-05-26', '5', 'ORDERED', 'TAKEAWAY', 6),
(16, '1', '1', '1', '3', '2022-05-27', '3', 'PAYED', 'TAKEAWAY', 7),
(17, '2', '1', '2', '5', '2022-05-27', '3', 'PAYED', 'TAKEAWAY', 7),
(18, '1', '1', '5', '3', '2022-05-27', '3', 'PAYED', 'TAKEAWAY', 8),
(19, '2', '1', '5', '5', '2022-05-27', '3', 'PAYED', 'TAKEAWAY', 8),
(21, '2', '1', '10', '5', '2022-05-29', '2', 'PAYED', 'TAKEAWAY', 9),
(22, '1', '1', '2', '3', '2022-05-29', '2', 'PAYED', 'TAKEAWAY', 10);

-- --------------------------------------------------------

--
-- Table structure for table `deliveryboy`
--

CREATE TABLE IF NOT EXISTS `deliveryboy` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `address` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `donor`
--

CREATE TABLE IF NOT EXISTS `donor` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(30) NOT NULL,
  `phoneno` int(50) NOT NULL,
  `blood_group` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `donor`
--

INSERT INTO `donor` (`id`, `full_name`, `address`, `pincode`, `phoneno`, `blood_group`) VALUES
(1, 'Arjun', 'arjun@gmail.com', 0, 2, 'blood_bank'),
(2, 'Arjun', 'arjun@gmail.com', 0, 15, 'blood_bank'),
(4, 'Hhgh', 'Bbghh', 0, 9677, 'Ghh'),
(5, 'Ywyww', 'Yagagaa', 566, 797, 'Gvv');

-- --------------------------------------------------------

--
-- Table structure for table `medical_reg`
--

CREATE TABLE IF NOT EXISTS `medical_reg` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `store_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact_number` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `medical_reg`
--

INSERT INTO `medical_reg` (`id`, `store_name`, `email`, `password`, `contact_number`) VALUES
(1, 'Pharm A', 'pharm@gmail.com', '123', '123'),
(2, 'Pharm B', 'pharmB@gmail.com', '123', '944');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `store` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `price` varchar(500) NOT NULL,
  `disease` varchar(600) NOT NULL,
  `symptom` varchar(500) NOT NULL,
  `stock` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `store`, `name`, `quantity`, `price`, `disease`, `symptom`, `stock`) VALUES
(1, 1, 'Paracetamol', '17', '3', 'Cough', 'headache , temprature', 'Available'),
(2, 1, 'Dolo', '28', '5', 'Pewer', 'Peeeewweeeerrrr', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `prescription`
--

CREATE TABLE IF NOT EXISTS `prescription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `prescription` tinytext NOT NULL,
  `status` varchar(100) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `prescription`
--

INSERT INTO `prescription` (`id`, `user`, `amount`, `prescription`, `status`, `address`) VALUES
(1, 3, 6, '../prescription/uploads/', 'TAKEAWAY', ''),
(2, 3, 6, '../prescription/uploads/', 'TAKEAWAY', ''),
(3, 3, 6, '../prescription/uploads/', 'TAKEAWAY', ''),
(4, 3, 15, '../prescription/uploads/', 'TAKEAWAY', ''),
(5, 3, 15, '../prescription/uploads/', 'TAKEAWAY', ''),
(6, 5, 6, '../prescription/uploads/', 'TAKEAWAY', ''),
(7, 3, 13, '../prescription/uploads/', 'TAKEAWAY', ''),
(8, 3, 40, '../prescription/uploads/', 'TAKEAWAY', ''),
(9, 2, 50, '../prescription/uploads/IMG-20220529-WA0007.jpg', 'TAKEAWAY', 'Alpy'),
(10, 2, 6, '../prescription/uploads/IMG-20220529-WA0007.jpg', 'TAKEAWAY', '');

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `age` varchar(100) NOT NULL,
  `blood_group` varchar(200) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user_tbl`
--

CREATE TABLE IF NOT EXISTS `user_tbl` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `blood_group` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_tbl`
--

INSERT INTO `user_tbl` (`id`, `name`, `email`, `phone`, `address`, `blood_group`, `username`, `password`) VALUES
(2, 'test', 'test@test.com', '944', 'test', 'b+ve', 'test@test.com', 'test'),
(3, 'Arjun', 'arjun@gmail.com', '9446739232', 'aa', 'b+ve', 'arjun', '123'),
(4, 'tt', 'tt@gmail.com', '99', 'tt', 'tt', 'tt', 'ttt'),
(5, 'Joseph', 'joseph@gmail.com', '9766', 'shgrv', 'b+ve', 'joseph@gmail.com', '123');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
