package com.example.helperhand;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    Button profileBT;
    Button cartBT;
    Button medicineBT;
    Button donorBT;
    Button viewBT;
    Button historyBT;

    private GlobalPreference globalPreference;
    private String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        globalPreference = new GlobalPreference(this);
        uid = globalPreference.getID();

        profileBT = findViewById(R.id.profileButton);
        cartBT = findViewById(R.id.cartButton);
        medicineBT = findViewById(R.id.medicineButton);
        donorBT = findViewById(R.id.donorButton);
        viewBT = findViewById(R.id.donor2Button);
        historyBT = findViewById(R.id.historyButton);

        profileBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this,WebActivity.class);
                intent.putExtra("function","profile");
                intent.putExtra("user_id","uid");
                startActivity(intent);
            }
        });

        cartBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this,WebActivity.class);
                intent.putExtra("function","cart");
                startActivity(intent);
            }
        });
        medicineBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this,WebActivity.class);
                intent.putExtra("function","medicine");
                startActivity(intent);
            }
        });
        donorBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this,WebActivity.class);
                intent.putExtra("function","donor");
                startActivity(intent);
            }
        });
        viewBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this,WebActivity.class);
                intent.putExtra("function","viewdonors");
                startActivity(intent);
            }
        });
        historyBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this,WebActivity.class);
                intent.putExtra("function","history");
                startActivity(intent);
            }
        });
    }
}